import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate, useParams } from "react-router-dom";
import { fetchParticipantById, queryKeys } from "@/lib/data";
import { parseNullableNumber, parseOptionalString, requireString } from "@/lib/forms";
import { createPerformanceTest } from "@/lib/mutations";
import { NotFoundPage } from "@/pages/not-found-page";

export function NewPerformanceTestPage() {
  const { id } = useParams<{ id: string }>();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const participantQuery = useQuery({
    queryKey: queryKeys.participant(id ?? ""),
    queryFn: () => fetchParticipantById(id ?? ""),
    enabled: !!id,
  });

  const mutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const testDate = requireString(formData.get("test_date"), "Testdatum");
      const ageGroup = parseOptionalString(formData.get("age_group"));
      const reachHeight = parseNullableNumber(formData.get("reach_height_cm"));
      const jumpReach = parseNullableNumber(formData.get("jump_reach_cm"));
      const sprint = parseNullableNumber(formData.get("sprint_93639_seconds"));
      const ballControl = parseNullableNumber(formData.get("ball_control_count"));

      if (!id) {
        throw new Error("Fehlende ID.");
      }

      await createPerformanceTest(id, {
        testDate,
        ageGroup,
        reachHeight,
        jumpReach,
        sprint,
        ballControl,
      });
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: queryKeys.performanceTestsByParticipant(id ?? ""),
      });
      await queryClient.invalidateQueries({ queryKey: queryKeys.dashboard });
      await queryClient.invalidateQueries({ queryKey: queryKeys.comparison });
      if (id) {
        navigate(`/athletes/${id}`);
      }
    },
    onError: (error) => {
      setErrorMessage(error instanceof Error ? error.message : "Speichern fehlgeschlagen.");
    },
  });

  if (participantQuery.isPending) {
    return <p className="text-sm text-zinc-500">Lade Athlet:in...</p>;
  }

  if (!id) {
    return <NotFoundPage />;
  }

  if (participantQuery.isError) {
    return <p className="text-sm text-red-700">{participantQuery.error.message}</p>;
  }

  const participant = participantQuery.data;

  if (!participant) {
    return <NotFoundPage />;
  }

  return (
    <>
      <header className="mb-8">
        <Link
          to={`/athletes/${participant.id}`}
          className="text-sm text-zinc-500 hover:text-zinc-900"
        >
          {`<- ${participant.name}`}
        </Link>
        <h1 className="mt-4 text-3xl font-semibold tracking-tight">Leistungstest hinzufuegen</h1>
        <p className="mt-2 text-sm text-zinc-500">
          {participant.name}
          {participant.birth_year ? ` · Jahrgang ${participant.birth_year}` : ""}
        </p>
      </header>

      <form
        className="max-w-2xl space-y-6 rounded-xl border border-zinc-200 bg-white p-6"
        onSubmit={(event) => {
          event.preventDefault();
          setErrorMessage(null);
          mutation.mutate(new FormData(event.currentTarget));
        }}
      >
        <TestFields />

        {errorMessage ? <p className="text-sm text-red-700">{errorMessage}</p> : null}

        <div className="flex gap-3">
          <button
            type="submit"
            disabled={mutation.isPending}
            className="rounded-lg bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-700 disabled:opacity-60"
          >
            {mutation.isPending ? "Speichert..." : "Test speichern"}
          </button>

          <Link
            to={`/athletes/${participant.id}`}
            className="rounded-lg border border-zinc-300 px-4 py-2 text-sm font-medium hover:bg-zinc-50"
          >
            Abbrechen
          </Link>
        </div>
      </form>
    </>
  );
}

function TestFields() {
  return (
    <>
      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="test_date" className="mb-1 block text-sm font-medium">
            Testdatum
          </label>
          <input
            id="test_date"
            name="test_date"
            type="date"
            required
            className="w-full rounded-lg border border-zinc-300 px-3 py-2"
          />
        </div>

        <div>
          <label htmlFor="age_group" className="mb-1 block text-sm font-medium">
            Altersklasse
          </label>
          <input
            id="age_group"
            name="age_group"
            type="text"
            placeholder="z. B. U14"
            className="w-full rounded-lg border border-zinc-300 px-3 py-2"
          />
        </div>
      </div>

      <div className="grid gap-6 sm:grid-cols-2">
        <NumberWithUnit id="reach_height_cm" label="Reichhoehe" unit="cm" min="1" step="1" />
        <NumberWithUnit id="jump_reach_cm" label="Sprunghoehe" unit="cm" min="1" step="1" />
      </div>

      <div className="grid gap-6 sm:grid-cols-2">
        <NumberWithUnit id="sprint_93639_seconds" label="9-3-6-3-9" unit="s" min="0" step="0.01" />
        <div>
          <label htmlFor="ball_control_count" className="mb-1 block text-sm font-medium">
            Ballkontrolle
          </label>
          <input
            id="ball_control_count"
            name="ball_control_count"
            type="number"
            min="0"
            step="1"
            className="w-full rounded-lg border border-zinc-300 px-3 py-2"
          />
        </div>
      </div>
    </>
  );
}

type NumberWithUnitProps = {
  id: string;
  label: string;
  unit: string;
  min: string;
  step: string;
};

function NumberWithUnit({ id, label, unit, min, step }: NumberWithUnitProps) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium">
        {label}
      </label>
      <div className="flex">
        <input
          id={id}
          name={id}
          type="number"
          min={min}
          step={step}
          className="w-full rounded-l-lg border border-zinc-300 px-3 py-2"
        />
        <span className="flex items-center rounded-r-lg border border-l-0 border-zinc-300 bg-zinc-50 px-3 text-sm text-zinc-500">
          {unit}
        </span>
      </div>
    </div>
  );
}
